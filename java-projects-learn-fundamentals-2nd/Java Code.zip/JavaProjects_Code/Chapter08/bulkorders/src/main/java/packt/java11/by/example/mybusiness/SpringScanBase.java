package packt.java11.by.example.mybusiness;


public interface SpringScanBase {
}
