package packt.java11.bulkorder;

import org.springframework.context.annotation.Configuration;

@Configuration
public class SpringConfiguration {

}
