package packt.java11.mybusiness;


public interface SpringScanBase {
}
