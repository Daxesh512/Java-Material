package com.javax0.aptools;

/**
 * Alias class for {@link AbstractToolFactory}
 *
 */
public class InThe extends AbstractToolFactory {

}
