// START SNIPPET module_info_SortInterface
module packt.java189fundamentals.SortInterface{
    exports packt.java189fundamentals.ch03;
    exports packt.java189fundamentals.ch03.generic;
}
// END SNIPPET