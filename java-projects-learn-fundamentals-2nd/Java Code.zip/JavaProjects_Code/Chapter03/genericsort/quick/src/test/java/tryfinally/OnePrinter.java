package tryfinally;

public class OnePrinter {
    private static final Integer ONE = 1;
    public static void printOne(){
        System.out.println(ONE);
    }
}
