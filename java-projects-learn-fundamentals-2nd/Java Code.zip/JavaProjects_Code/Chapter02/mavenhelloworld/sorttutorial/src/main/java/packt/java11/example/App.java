// START SNIPPET AppHelloWorld
package packt.java11.example;

public class App {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}
//END SNIPPET