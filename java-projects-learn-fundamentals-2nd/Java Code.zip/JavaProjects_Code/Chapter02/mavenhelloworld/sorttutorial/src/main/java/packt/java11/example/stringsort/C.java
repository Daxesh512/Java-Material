package packt.java11.example.stringsort;

public class C extends B{
    public static void a(){
        System.out.println("c");
    }
}
