package packt.java11.example.stringsort;

public class B extends A {
    public static void main(String[] args) {
        a();
        ((B)new C()).a();
        C.a();
    }
}
