package packt.java11.example.stringsort;

public class A {

    public static void a(){
        System.out.println("a");
    }

}
